<template>
    
    <!-- <div>Index</div> -->
    
    
</template>
<script setup>
import {Link} from '@inertiajs/vue3'
</script>
