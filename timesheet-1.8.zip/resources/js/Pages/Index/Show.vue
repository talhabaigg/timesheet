<template>

    <div>Show</div>
   
</template>
<script setup>
import {Link} from '@inertiajs/vue3'
</script>

